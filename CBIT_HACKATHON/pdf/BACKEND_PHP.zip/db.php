<?php
$host="localhost:3306";
$user="root";
$pass="manoj@hp";
$db="pdf";

$conn=mysqli_connect($host,$user,$pass,$db);

 ?>